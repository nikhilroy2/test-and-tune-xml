function SetControl(idName) {
    this.idName = idName
}


const myControl = new SetControl('Hello');


console.log(myControl)